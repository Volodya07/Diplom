﻿using System;
using System.Collections.Generic;

namespace WinFormsDiplom.Views;

public partial class ViewEmp
{
    public string? Фамилия { get; set; }

    public string? Имя { get; set; }

    public string? Отчество { get; set; }

    public string? Кафедра { get; set; }

    public string? Отдел { get; set; }

    public string? Должность { get; set; }

    public string? Категория { get; set; }
}
