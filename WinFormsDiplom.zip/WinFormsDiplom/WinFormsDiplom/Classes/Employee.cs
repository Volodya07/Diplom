﻿using System;
using System.Collections.Generic;

namespace WinFormsDiplom.Classes;

public partial class Employee
{
    public int IdEmployee { get; set; }

    public string? Surname { get; set; }

    public string? Firstname { get; set; }

    public string? Lastname { get; set; }

    public int? IdCategory { get; set; }

    public int? IdDeparment { get; set; }

    public int? IdDivision { get; set; }

    public string? Post { get; set; }

    public virtual Category? IdCategoryNavigation { get; set; }

    public virtual Department? IdDeparmentNavigation { get; set; }

    public virtual Division? IdDivisionNavigation { get; set; }

    public virtual ICollection<Workload> Workloads { get; set; } = new List<Workload>();
}
