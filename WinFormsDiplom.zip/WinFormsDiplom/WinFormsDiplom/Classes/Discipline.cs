﻿using System;
using System.Collections.Generic;

namespace WinFormsDiplom.Classes;

public partial class Discipline
{
    public int IdDesciplines { get; set; }

    public string? NameDisciplines { get; set; }

    public int? IdGroup { get; set; }

    public int? CountHours { get; set; }

    public virtual Group? IdGroupNavigation { get; set; }

    public virtual ICollection<Workload> Workloads { get; set; } = new List<Workload>();
}
