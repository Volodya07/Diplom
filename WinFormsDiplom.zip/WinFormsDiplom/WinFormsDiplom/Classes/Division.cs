﻿using System;
using System.Collections.Generic;

namespace WinFormsDiplom.Classes;

public partial class Division
{
    public int IdDivision { get; set; }

    public string? NameDivision { get; set; }

    public int? IdDepartment { get; set; }

    public virtual ICollection<Employee> Employees { get; set; } = new List<Employee>();

    public virtual Department? IdDepartmentNavigation { get; set; }
}
