﻿using System;
using System.Collections.Generic;

namespace WinFormsDiplom.Classes;

public partial class Profession
{
    public int IdProfession { get; set; }

    public string? NameProfession { get; set; }

    public virtual ICollection<Group> Groups { get; set; } = new List<Group>();
}
