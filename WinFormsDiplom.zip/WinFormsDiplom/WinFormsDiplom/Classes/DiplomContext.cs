﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using WinFormsDiplom.Views;

namespace WinFormsDiplom.Classes;

public partial class DiplomContext : DbContext
{
    public DiplomContext()
    {
    }

    public DiplomContext(DbContextOptions<DiplomContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<Discipline> Disciplines { get; set; }

    public virtual DbSet<Division> Divisions { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<Group> Groups { get; set; }

    public virtual DbSet<Profession> Professions { get; set; }

    public virtual DbSet<ViewEmp> ViewEmps { get; set; }

    public virtual DbSet<Workload> Workloads { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=DESKTOP1\\SQLExpress;Database=Diplom;Trusted_Connection=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(e => e.IdCategory);

            entity.ToTable("Category");

            entity.Property(e => e.IdCategory).HasColumnName("id_category");
            entity.Property(e => e.NameCategory)
                .HasMaxLength(25)
                .IsUnicode(false)
                .HasColumnName("name_category");
        });

        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.IdDepartment);

            entity.ToTable("Department");

            entity.Property(e => e.IdDepartment).HasColumnName("id_department");
            entity.Property(e => e.HeadDepartment)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("head_department");
            entity.Property(e => e.NameDepartment)
                .IsUnicode(false)
                .HasColumnName("name_department");
        });

        modelBuilder.Entity<Discipline>(entity =>
        {
            entity.HasKey(e => e.IdDesciplines);

            entity.Property(e => e.IdDesciplines).HasColumnName("id_desciplines");
            entity.Property(e => e.CountHours).HasColumnName("count_hours");
            entity.Property(e => e.IdGroup).HasColumnName("id_group");
            entity.Property(e => e.NameDisciplines)
                .IsUnicode(false)
                .HasColumnName("name_disciplines");

            entity.HasOne(d => d.IdGroupNavigation).WithMany(p => p.Disciplines)
                .HasForeignKey(d => d.IdGroup)
                .HasConstraintName("FK_Disciplines_Group");
        });

        modelBuilder.Entity<Division>(entity =>
        {
            entity.HasKey(e => e.IdDivision);

            entity.ToTable("Division");

            entity.Property(e => e.IdDivision).HasColumnName("id_division");
            entity.Property(e => e.IdDepartment).HasColumnName("id_department");
            entity.Property(e => e.NameDivision)
                .IsUnicode(false)
                .HasColumnName("name_division");

            entity.HasOne(d => d.IdDepartmentNavigation).WithMany(p => p.Divisions)
                .HasForeignKey(d => d.IdDepartment)
                .HasConstraintName("FK_Division_Department");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.IdEmployee);

            entity.ToTable("Employee");

            entity.Property(e => e.IdEmployee).HasColumnName("id_employee");
            entity.Property(e => e.Firstname)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("firstname");
            entity.Property(e => e.IdCategory).HasColumnName("id_category");
            entity.Property(e => e.IdDeparment).HasColumnName("id_deparment");
            entity.Property(e => e.IdDivision).HasColumnName("id_division");
            entity.Property(e => e.Lastname)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("lastname");
            entity.Property(e => e.Post)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("post");
            entity.Property(e => e.Surname)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("surname");

            entity.HasOne(d => d.IdCategoryNavigation).WithMany(p => p.Employees)
                .HasForeignKey(d => d.IdCategory)
                .HasConstraintName("FK_Employee_Category");

            entity.HasOne(d => d.IdDeparmentNavigation).WithMany(p => p.Employees)
                .HasForeignKey(d => d.IdDeparment)
                .HasConstraintName("FK_Employee_Department");

            entity.HasOne(d => d.IdDivisionNavigation).WithMany(p => p.Employees)
                .HasForeignKey(d => d.IdDivision)
                .HasConstraintName("FK_Employee_Division");
        });

        modelBuilder.Entity<Group>(entity =>
        {
            entity.HasKey(e => e.IdGroup);

            entity.ToTable("Group");

            entity.Property(e => e.IdGroup).HasColumnName("id_group");
            entity.Property(e => e.IdDivision).HasColumnName("id_division");
            entity.Property(e => e.IdProfession).HasColumnName("id_profession");
            entity.Property(e => e.NameGroup)
                .IsUnicode(false)
                .HasColumnName("name_group");
            entity.Property(e => e.YearFinish).HasColumnName("year_finish");
            entity.Property(e => e.YearStart).HasColumnName("year_start");

            entity.HasOne(d => d.IdProfessionNavigation).WithMany(p => p.Groups)
                .HasForeignKey(d => d.IdProfession)
                .HasConstraintName("FK_Group_Profession");
        });

        modelBuilder.Entity<Profession>(entity =>
        {
            entity.HasKey(e => e.IdProfession);

            entity.ToTable("Profession");

            entity.Property(e => e.IdProfession).HasColumnName("id_profession");
            entity.Property(e => e.NameProfession)
                .IsUnicode(false)
                .HasColumnName("name_profession");
        });

        modelBuilder.Entity<ViewEmp>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("viewEMP");

            entity.Property(e => e.Должность)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Имя)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Категория)
                .HasMaxLength(25)
                .IsUnicode(false);
            entity.Property(e => e.Кафедра).IsUnicode(false);
            entity.Property(e => e.Отдел).IsUnicode(false);
            entity.Property(e => e.Отчество)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("отчество");
            entity.Property(e => e.Фамилия)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Workload>(entity =>
        {
            entity.HasKey(e => e.IdWorkload);

            entity.ToTable("workload");

            entity.Property(e => e.IdWorkload).HasColumnName("id_workload");
            entity.Property(e => e.IdDisciplines).HasColumnName("id_disciplines");
            entity.Property(e => e.IdEmployee).HasColumnName("id_employee");

            entity.HasOne(d => d.IdDisciplinesNavigation).WithMany(p => p.Workloads)
                .HasForeignKey(d => d.IdDisciplines)
                .HasConstraintName("FK_workload_Disciplines");

            entity.HasOne(d => d.IdEmployeeNavigation).WithMany(p => p.Workloads)
                .HasForeignKey(d => d.IdEmployee)
                .HasConstraintName("FK_workload_Employee");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
