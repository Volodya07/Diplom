﻿using System;
using System.Collections.Generic;

namespace WinFormsDiplom.Classes;

public partial class Workload
{
    public int IdWorkload { get; set; }

    public int? IdEmployee { get; set; }

    public int? IdDisciplines { get; set; }

    public virtual Discipline? IdDisciplinesNavigation { get; set; }

    public virtual Employee? IdEmployeeNavigation { get; set; }
}
