﻿using System;
using System.Collections.Generic;

namespace WinFormsDiplom.Classes;

public partial class Department
{
    public int IdDepartment { get; set; }

    public string? NameDepartment { get; set; }

    public string? HeadDepartment { get; set; }

    public virtual ICollection<Division> Divisions { get; set; } = new List<Division>();

    public virtual ICollection<Employee> Employees { get; set; } = new List<Employee>();
}
