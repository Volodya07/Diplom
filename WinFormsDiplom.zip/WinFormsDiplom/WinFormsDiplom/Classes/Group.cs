﻿using System;
using System.Collections.Generic;

namespace WinFormsDiplom.Classes;

public partial class Group
{
    public int IdGroup { get; set; }

    public string? NameGroup { get; set; }

    public int? IdProfession { get; set; }

    public DateOnly? YearStart { get; set; }

    public DateOnly? YearFinish { get; set; }

    public int? IdDivision { get; set; }

    public virtual ICollection<Discipline> Disciplines { get; set; } = new List<Discipline>();

    public virtual Profession? IdProfessionNavigation { get; set; }
}
