﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsDiplom.Classes;

namespace WinFormsDiplom.Forms
{
    public partial class FormData : Form
    {
        //DiplomContext diplomContext = new DiplomContext();
        public FormData()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void FormData_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }

        private void FormData_Load(object sender, EventArgs e)
        {
            //dataGridView1.DataSource = diplomContext.Divisions.ToArray();
        }
    }
}
