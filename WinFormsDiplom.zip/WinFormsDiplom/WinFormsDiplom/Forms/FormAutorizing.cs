using WinFormsDiplom.Forms;

namespace WinFormsDiplom
{
    public partial class FormAutorizing : Form
    {
        public FormAutorizing()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void FormAutorizing_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }

        private void btn_Enter_Click(object sender, EventArgs e)
        {
            FormCard formCard = new FormCard();
            formCard.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormData formData = new FormData();
            formData.Show();
            this.Hide();
        }
    }
}
