﻿using WinFormsDiplom.Classes;

namespace WinFormsDiplom.Forms
{
    public partial class FormCard : Form
    {
        public FormCard()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void FormCard_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }
        /// <summary>
        /// Выбор ФИО преподавателя
        /// </summary>
        private void FormCard_Load(object sender, EventArgs e)
        {
            using (DiplomContext diplom = new())
            {
                var emp = diplom.ViewEmps.ToList();
                foreach (var item in emp)
                {
                    comboBox1.Items.AddRange([$"{item.Фамилия} {item.Имя} {item.Отчество}"]);
                }
            }
        }
        /// <summary>
        /// Добавляем в другие combobox данные из таблицы
        /// </summary>
        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            using (DiplomContext diplom = new())
            {
                var emp = diplom.ViewEmps;
                foreach (var item in emp)
                {
                    if (item.Фамилия == "Аблязова")
                    {
                        comboBox2.Text = item.Кафедра;
                        comboBox3.Text = item.Отдел;
                        comboBox4.Text = item.Должность;
                        comboBox5.Text = item.Категория;
                    }
                }
            }
        }
    }
}
